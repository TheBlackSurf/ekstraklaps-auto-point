## Betting
![alt text](ss/4.png)
![alt text](ss/5.png)
![alt text](ss/1.png)
![alt text](ss/2.png)
![alt text](ss/3.png)
