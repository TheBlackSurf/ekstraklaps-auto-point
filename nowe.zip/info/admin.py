from django.contrib import admin
from .models import Info, Comment
# Register your models here.


admin.site.register(Info)
admin.site.register(Comment)