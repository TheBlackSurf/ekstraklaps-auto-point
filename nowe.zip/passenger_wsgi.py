import os
import sys
from betting.wsgi import application
